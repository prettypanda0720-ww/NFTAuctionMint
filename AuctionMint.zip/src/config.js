export const contractAddress = '0xDd9606Fb10357267BB4948E9483091678Af87263'
export const presalePrice = '0.05'
export const RINKEBY_HTTP_URL = 'https://rinkeby.infura.io/v3/425c3111767749ffa1a4ad4972faea51'
export const MAINNET_HTTP_URL = 'https://mainnet.infura.io/v3/425c3111767749ffa1a4ad4972faea51'
